export const LabMeterial = [{
    laboneVideo: 'https://cdn.shopify.com/s/files/1/0997/6284/files/Motion_1_-_Dektop.mp4?v=1652240513',
    labtwoImglg: 'https://cdn.shopify.com/s/files/1/0997/6284/files/s_02_desk_1500x.png?v=1652243490',
    labtwoImgsm: 'https://cdn.shopify.com/s/files/1/0997/6284/files/s_02_mob_6808263b-c56e-4c83-8dc0-7d9d90563ba1_900x.png?v=1652254609',
    labthreeImglg: 'https://cdn.shopify.com/s/files/1/0997/6284/files/Rectangle_674_1500x.png?v=1652241098',
    labthreeImgsm: 'https://cdn.shopify.com/s/files/1/0997/6284/files/s_03_mob_900x.png?v=1652254610',
    labFourthImglg:'https://cdn.shopify.com/s/files/1/0997/6284/files/Rectangle_674_4_1_1_1_1500x.png?v=1652243589',
    labFourthImgsm:'https://cdn.shopify.com/s/files/1/0997/6284/files/s_04_mob_1000x.png?v=1652254609',
    labfifthImglg:'https://cdn.shopify.com/s/files/1/0997/6284/files/Group_4423118_1_1_1500x.png?v=1652243840',
    labfifthImgsm:'https://cdn.shopify.com/s/files/1/0997/6284/files/s_05_mob_1000x.png?v=1652254610',
    labsixImglg:'https://cdn.shopify.com/s/files/1/0997/6284/files/s_06_desk_1500x.png?v=1652245788',
    labsixImgsm:'https://cdn.shopify.com/s/files/1/0997/6284/files/s_06_mob_c294cc53-fac0-4321-8f05-2edc74a741cf_1000x.png?v=1652254609',
    labLastvdo:'https://cdn.shopify.com/s/files/1/0997/6284/files/Motion_2_-_Desktop_b0525d08-58a7-4be4-be34-8eb7fb4006a7.mp4?v=1652240513',
    labseventhLg:'https://cdn.shopify.com/s/files/1/0997/6284/files/Desk_1_1_1_1_1_1500x.png?v=1652422593',
    labseventhsm:'https://cdn.shopify.com/s/files/1/0997/6284/files/Mbl_1_1_1_1_1_1_1000x.png?v=1652422592'
}]